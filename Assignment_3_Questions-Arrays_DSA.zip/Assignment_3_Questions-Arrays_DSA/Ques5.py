def plusOne(digits):
    n = len(digits)
    carry = 1
    for i in range(n - 1, -1, -1):
        digits[i] += carry
        if digits[i] < 10:
            carry = 0
            break
        else:
            digits[i] = 0
    if carry:
        digits.insert(0, 1)

    return digits
# Test example
digits = [1, 2, 3]
result = plusOne(digits)
print(result)
