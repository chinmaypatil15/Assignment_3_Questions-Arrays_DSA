def searchInsert(nums, target):
    left = 0
    right = len(nums) - 1
    result = len(nums)
    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            return mid
        elif nums[mid] < target:
            left = mid + 1
        else:
            result = mid
            right = mid - 1
    return result

nums = [1, 3, 5, 6]
target = 5
result = searchInsert(nums, target)
print(result)
