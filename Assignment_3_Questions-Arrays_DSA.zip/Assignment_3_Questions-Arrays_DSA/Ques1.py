def threeSum(Arr, target):
    Arr.sort()
    n = len(Arr)
    closestSum = float('inf')
    for i in range(n - 2):
        left = i + 1
        right = n - 1
        while left < right:
            currentSum = Arr[i] + Arr[left] + Arr[right]
            if currentSum == target:
                return currentSum
            if abs(currentSum - target) < abs(closestSum - target):
                closestSum = currentSum
            if currentSum < target:
                left += 1
            else:
                right -= 1
    return closestSum
Arr = [-1, 2, 1, -4]
target = 1

result = threeSum(Arr, target)
print(result)
